input('how much hamburgers do you want?')
input ('are you sure? ;)')
print ('alright i got you.')
i=1
while i<=999:
    print(i)
    i=i+1
quit
    