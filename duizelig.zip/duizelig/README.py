i = 30
while i>=1:
    print(i)
    i = i - 1
    