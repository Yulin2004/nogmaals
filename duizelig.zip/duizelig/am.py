i = 1
while i <=11:
    print (i, 'am')
    i=i+1
    x = 12
while x <=24:
     print (x, 'pm')
     x=x+1
