input ('hoeveel is 50+50+50 etc..? begin bij 50 en voeg elke keer +50')

i=50
while i<=1500:
    print(i)
    i=i+50
print ('ik heb het al voor je gedaan :)')