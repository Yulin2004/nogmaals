print ('hello, what day is it?')

 #de dagen
i=1
while i<=1:
    print (i, 'monday')
    i=i+1
b=2
while b<=2:
    print (b, 'tuesday')
    b=b+1
c=3
while c<=3:
    print (c,'wednesday')
    c=c+1
d=4
while d<=4:
    print (d, 'thursday')
    d=d+1
e=5
while e<=5:
    print (e, 'friday')
    e=e+1
f=6
while f<=6:
    print (f, 'saturday')
    f=f+1
s=7
while s<=7:
    print(s, 'sunday')
    s=s+1






